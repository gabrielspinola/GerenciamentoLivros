from pydantic import BaseModel, field_validator
from typing import Dict, Any, Literal

class LivroModel(BaseModel):
    idlivro: int = 0
    titulo: str
    autor: str
    ano_publicacao: int
    genero: str
    bloqueado: Literal["S", "N"] = "N"

    @field_validator("ano_publicacao", mode="before")
    @classmethod
    def validar_ano(cls, v):
        return int(v)

    @field_validator("bloqueado", mode="before")
    @classmethod
    def validar_bloqueado(cls, v):
        if v is None:
            return "N"
        v = str(v).strip().upper()
        if v not in ("S", "N"):
            raise ValueError(
                f"Campo 'bloqueado' deve ser 'S' ou 'N', recebido: {v!r}"
            )
        return v

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LivroModel":
        return cls(**data)

    @classmethod
    def from_row(cls, row: tuple) -> "LivroModel":
        # Cria instância a partir de uma linha do banco
        return cls(
            idlivro=row[0],
            titulo=row[1],
            autor=row[2],
            ano_publicacao=row[3],
            genero=row[4],
            bloqueado=row[5],
        )